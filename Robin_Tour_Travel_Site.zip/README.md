
# Tour & Travel Website

A simple tour and travel website made using HTML and CSS.

## Features
- Header with logo and navigation
- Banner with centered text and message
- List of booking options (Hotel, Flight, Resort)
- Custom fonts and styling

## Technologies Used
- HTML5
- CSS3
- Google Fonts

## How to Use
1. Open `index.html` in a browser to view the site.
2. Upload all files to GitHub repository to host with GitHub Pages.

## Author
Robin (2025)
